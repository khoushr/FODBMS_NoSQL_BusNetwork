from flask_pymongo import PyMongo

mongo = PyMongo()
#BusNetwork = mongo.db

