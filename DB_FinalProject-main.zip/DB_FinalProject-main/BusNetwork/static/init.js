(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.tabs').tabs();


  }); // end of document ready

  
})(jQuery); // end of jQuery name space
